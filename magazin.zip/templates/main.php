<div id = "promo">
	<h1 id = "promoText">

	</h1>
</div>
<div id = "mainTextWrap">
	<div id = "mainText">

	</div>
</div>